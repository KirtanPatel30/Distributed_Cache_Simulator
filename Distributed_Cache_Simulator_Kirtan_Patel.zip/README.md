# Distributed Cache Simulator (Python)

A local simulator for a distributed in-memory cache system.
No external libraries required. Runs fully in VS Code.

## Run
python main.py

## What it simulates
- Sharding
- Replication
- LRU / LFU eviction
- TTL expiration
- Cache hit/miss metrics
- Latency simulation
